package com.torres;

public abstract class Persona {

    static
    {
        System.out.println("[Sistema] Cargando infraestructura de Persona...");
    }

    private String nombre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    {
        System.out.println("[Persona] Inicializando datos básicos del individuo...");
    }

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    
    
    
}
