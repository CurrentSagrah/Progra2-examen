package com.torres;

interface MetodoPago {

    abstract void procesarPago(double monto);
    
}
