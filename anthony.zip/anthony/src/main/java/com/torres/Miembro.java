package com.torres;

public class Miembro extends Persona {

    static
    {
        System.out.println("[Sistema] Cargando extensión específica para Miembros...");
    }

    private int id = 1;
    public static int contadorId;
    private int[][] minutosPorEjercicio = new int[3][];

    public int[][] getMinutosPorEjercicio() {
        return minutosPorEjercicio;
    }

    public void setMinutosPorEjercicio(int[][] minutosPorEjercicio) {
        this.minutosPorEjercicio = minutosPorEjercicio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Miembro(String nombre) {
        super(nombre);
    }

    {
        contadorId += id;
        System.out.println("[Miembro] Registro deportivo detectado. Asignando ID correlativo: " + contadorId);
    }

    public void definirPlanSemanal(int[] ejerciciosPorDia) {
        for (int i = 0; i< minutosPorEjercicio.length; i++) {
            minutosPorEjercicio[i] = new int[ejerciciosPorDia[i]];
        }
    }

    public int calcularTotalMinutos() {
        int resultado = 0;
        for (int i = 0; i < minutosPorEjercicio.length; i++) {
            for (int j = 0; j < minutosPorEjercicio[i].length; j++) {
                resultado += minutosPorEjercicio[i][j];
            }
        }
        return resultado;
    }

    public int calcularTotalMinutos(int dia) {
    int resultadoDia= 0;
        for (int i = 0; i < minutosPorEjercicio[1].length; i++) {
                resultadoDia += minutosPorEjercicio[1][i];
            }
        return resultadoDia;
    }


}
